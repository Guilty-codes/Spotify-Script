from dotenv import load_dotenv
import os
import base64
from requests import post, get
import json
import random


load_dotenv()

client_id = os.getenv("CLIENT_ID")
client_secret = os.getenv("CLIENT_SECRET")

def print_env_vars():
    # Print credentials
    print(f"Your Spotify API credentials:")
    print(f"CLIENT_ID: {client_id}")
    print(f"CLIENT_SECRET: {client_secret}")

def get_token():
    auth_string = client_id + ":" + client_secret
    auth_bytes = auth_string.encode("utf-8")
    auth_base64 = str(base64.b64encode(auth_bytes), "utf-8")

    url = "https://accounts.spotify.com/api/token"
    headers = {
        "Authorization": "Basic " + auth_base64,
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {"grant_type": "client_credentials"}
    result = post(url, headers=headers, data=data)
    json_result = json.loads(result.content)
    token = json_result["access_token"]
    return token

def search_spotify(token, query, search_type='playlist'):
    url = f"https://api.spotify.com/v1/search"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    params = {
        "q": query,
        "type": search_type,
        "market": "US",
        "limit": 1  
    }
    response = get(url, headers=headers, params=params)
    data = response.json()
    
    if search_type == 'playlist':
        items = data['playlists']['items']
    elif search_type == 'album':
        items = data['albums']['items']
    else:
        raise ValueError("Please specify 'playlist' or 'album' for the search type.")
    
    if items:
        return items[0]['id']
    else:
        raise ValueError(f"No {search_type.capitalize()} found matching '{query}'")

def get_playlist_tracks(token, playlist_id, excluded_tracks):
    tracks = []
    excluded_tracks_list = []
    url = f"https://api.spotify.com/v1/playlists/{playlist_id}/tracks"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    params = {
        "market": "US"
    }
    while url:
        response = get(url, headers=headers, params=params)
        data = response.json()
        for item in data['items']:
            track = item['track']
            track_name = track['name'].lower()
            exclude = False
            for exclude_track in excluded_tracks:
                if track_name.startswith(exclude_track.lower()):
                    excluded_tracks_list.append(track['name'])
                    exclude = True
                    break
            if not exclude:
                tracks.append(track)
        url = data['next']
    
    if excluded_tracks_list:
        print("\nThe following tracks are excluded:")
        for track_name in excluded_tracks_list:
            print(track_name)
    
    return tracks

def get_album_tracks(token, album_id, excluded_tracks):
    tracks = []
    excluded_tracks_list = []
    url = f"https://api.spotify.com/v1/albums/{album_id}/tracks"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    while url:
        response = get(url, headers=headers, params=params)
        data = response.json()
        for item in data['items']:
            track_name = item['name'].lower()
            exclude = False
            for exclude_track in excluded_tracks:
                if track_name.startswith(exclude_track.lower()):
                    excluded_tracks_list.append(item['name'])
                    exclude = True
                    break
            if not exclude:
                tracks.append(item)
        url = data['next']
    
    if excluded_tracks_list:
        print("\nThe following tracks are excluded:")
        for track_name in excluded_tracks_list:
            print(track_name)
    
    return tracks

def custom_shuffle(token, source_id, excluded_tracks, source_type='playlist'):
    if source_type == 'playlist':
        tracks = get_playlist_tracks(token, source_id, excluded_tracks)
    elif source_type == 'album':
        tracks = get_album_tracks(token, source_id, excluded_tracks)
    else:
        raise ValueError("Please specify 'playlist' or 'album' for the source type.")
    
    random.shuffle(tracks)
    
    print("\nHere are the shuffled tracks:")
    for track in tracks:
        print(track['name'])
    
    return [track['uri'] for track in tracks]


def main():
    print("Pick an album or playlist to shuffle and exclude songs from")
    

    token = get_token()
    print_env_vars()

    
    query = input("\nEnter the name of the playlist or album : ")

    
    excluded_tracks_input = input("\nEnter any tracks you want to exclude seperate with commas, leave blank if you dont want to exclude songs): ")
    excluded_tracks = [track.strip().lower() for track in excluded_tracks_input.split(',') if excluded_tracks_input] if excluded_tracks_input else []

   
    source_type = input("\nDo you want to shuffle a playlist or an album? Enter 'playlist' or 'album': ").lower()

  
    try:
        source_id = search_spotify(token, query, search_type=source_type)
        print(f"\nFound {source_type} matching '{query}'. Shuffling now...")
    except ValueError as e:
        print(f"\nError: {e}")
        return

 
    shuffled_tracks = custom_shuffle(token, source_id, excluded_tracks, source_type)

    print("\n Here are the Spotify URIs:")
    for track_uri in shuffled_tracks:
        print(track_uri)  

if __name__ == "__main__":
    main()
